<?php
	/*
		by Lourdes Morales
		Turn the water on by executing the following
		command on the terminal, which runs the python
		file that actually turns the water off
	*/
	exec("sudo python turn_water_on.py");
?>